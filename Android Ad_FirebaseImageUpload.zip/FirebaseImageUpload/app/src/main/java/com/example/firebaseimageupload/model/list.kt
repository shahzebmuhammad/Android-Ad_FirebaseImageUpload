package com.example.firebaseimageupload.model

import android.net.Uri
import com.google.firebase.storage.StorageReference


class list(id: Int, urireference: Uri, fileRef: StorageReference) {

    var id: Int
    var uri: Uri
    var type: String

    init {
        this.id = id
        this.uri = urireference
        this.type = fileRef.toString()
    }

}
