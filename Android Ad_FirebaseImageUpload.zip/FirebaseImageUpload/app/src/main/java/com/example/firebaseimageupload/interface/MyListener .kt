package com.example.firebaseimageupload.`interface`

interface MyListener  {

    fun OnRefresh()

}