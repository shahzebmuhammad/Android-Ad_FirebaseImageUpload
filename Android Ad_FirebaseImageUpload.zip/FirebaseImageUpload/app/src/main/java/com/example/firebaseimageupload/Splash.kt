package com.example.firebaseimageupload



import android.os.Bundle
import android.os.Handler

import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseimageupload.Ad.InterstialAd
import com.google.android.gms.ads.interstitial.InterstitialAd


const val AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

class Splash : AppCompatActivity() {

    private lateinit var rotateAnimation: Animation
    val obj = InterstialAd(this)


    private var mInterstitialAd: InterstitialAd? = null
    private var mAdIsLoading: Boolean = false
    lateinit var image: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        image = findViewById(R.id.splash_imageview)
        rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate)
        image.animation = rotateAnimation
        obj.initilization()
        Handler().postDelayed({

            obj.showInterstitial()

        }, 8000) // 3000 is the delayed time in milliseconds.
    }





}