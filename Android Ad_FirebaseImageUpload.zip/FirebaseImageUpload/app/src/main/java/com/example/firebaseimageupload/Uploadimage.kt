package com.example.firebaseimageupload

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.firebaseimageupload.Ad.InterstialAd
import com.example.firebaseimageupload.`interface`.MyListener
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
import java.io.IOException
import java.util.*
import kotlin.collections.HashMap


class Uploadimage() : AppCompatActivity() {

    companion object {
        lateinit var listner: MyListener
    }

    val interstial = InterstialAd(this)


    private var mInterstitialAd: InterstitialAd? = null
    private var mAdIsLoading: Boolean = false

    private val PICK_IMAGE_REQUEST = 71
    private var filePath: Uri? = null
    private var firebaseStore: FirebaseStorage? = null
    private var storageReference: StorageReference? = null

    lateinit var btn_choose_image: Button
    lateinit var btn_upload_image: Button

    lateinit var image_preview: ImageView
    private lateinit var remoteConfig: FirebaseRemoteConfig
    var ad_view: AdView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uploadimage)

        remoteConfig = FirebaseRemoteConfig.getInstance()
        val firebasesetting = FirebaseRemoteConfigSettings.Builder()


        interstial.initilization()
        val xyz = firebasesetting.setMinimumFetchIntervalInSeconds(60).build()
        remoteConfig.setConfigSettingsAsync(xyz)
        remoteConfig.setDefaultsAsync(R.xml.defaultvalue)
        getvaluefromfirebaseconfig()

        firebaseStore = FirebaseStorage.getInstance()
        storageReference = FirebaseStorage.getInstance().reference

        btn_choose_image = findViewById(R.id.btn_choose_image)
        btn_upload_image = findViewById(R.id.btn_upload_image)

        image_preview = findViewById(R.id.image_preview)
        btn_choose_image.setOnClickListener { launchGallery() }
        btn_upload_image.setOnClickListener { uploadImage() }



    }



    //Remote Configuration Firebase////
    private fun getvaluefromfirebaseconfig() {
        remoteConfig.fetchAndActivate().addOnCompleteListener(this) { task ->

            if (task.isSuccessful) {
                val updated = task.result
                Log.d("TAG", "Config params updated: $updated")
                Toast.makeText(
                    this, "Fetch and activate succeeded from Firebase",
                    Toast.LENGTH_SHORT
                ).show()
                var buttintext: String = remoteConfig.getString("greeting_label")
                btn_choose_image.setText(buttintext)


            } else {
                Toast.makeText(
                    this, "Fetch failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
//Remote Configuration Firebase////

    private fun launchGallery() {
        val intent = Intent()
        intent.type = "*/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            if (data == null || data.data == null) {
                return
            }

            filePath = data.data

            Toast.makeText(this, "path" + filePath!!.path, Toast.LENGTH_SHORT).show()
            try {

                Glide
                    .with(applicationContext)
                    .load(filePath)
                    .into(image_preview)

            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun addUploadRecordToDb(uri: String) {
        val db = FirebaseFirestore.getInstance()

        val data = HashMap<String, Any>()
        data["imageUrl"] = uri

        db.collection("posts")
            .add(data)
            .addOnSuccessListener { documentReference ->
                Toast.makeText(this, "Saved to DB", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error saving to DB", Toast.LENGTH_LONG).show()
            }
    }

    private fun uploadImage() {

        if (filePath != null) {
            val ref = storageReference?.child("uploads/" + UUID.randomUUID().toString())
            val uploadTask = ref?.putFile(filePath!!)

            val urlTask =
                uploadTask?.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                    if (!task.isSuccessful) {
                        task.exception?.let {
                            throw it
                        }
                    }
                    return@Continuation ref.downloadUrl
                })?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val downloadUri = task.result
                        addUploadRecordToDb(downloadUri.toString())

                        Toast.makeText(this, "Successful", Toast.LENGTH_SHORT).show()
                        listner.OnRefresh()
                    } else {
                        Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show()
                    }
                }?.addOnFailureListener {

                }
        } else {
            Toast.makeText(this, "Please Upload an Image", Toast.LENGTH_SHORT).show()
        }
    }

    ////ad ///
    // Called when leaving the activity
    public override fun onPause() {
        ad_view?.pause()
        super.onPause()
    }

    // Called when returning to the activity
    public override fun onResume() {
        super.onResume()
        ad_view?.resume()
    }

    // Called before the activity is destroyed
    public override fun onDestroy() {
        ad_view?.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        interstial.showInterstitial()
    }
}