package com.example.firebaseimageupload

import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseimageupload.Adapter.ImageAdapter
import com.example.firebaseimageupload.`interface`.MyListener
import com.example.firebaseimageupload.internetconnectivity.ConnectivityReceiver
import com.example.firebaseimageupload.model.list
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage


class MainActivity : AppCompatActivity(), MyListener,
    ConnectivityReceiver.ConnectivityReceiverListener {

    lateinit var floatingActionButton: FloatingActionButton
    lateinit var recyclerView: RecyclerView
    var storageReference = FirebaseStorage.getInstance().reference.child("uploads")
    var database = FirebaseDatabase.getInstance()
    lateinit var imageList: ArrayList<list>
    lateinit var uriReference: ArrayList<Uri>
    lateinit var typeReference: ArrayList<String>
    lateinit var adapter: ImageAdapter

    private var mSnackBar: Snackbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        registerReceiver(
            ConnectivityReceiver(),
            IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        )


        imageList = ArrayList()
        uriReference = ArrayList()
        typeReference = ArrayList()

        GetImage()

        floatingActionButton = findViewById(R.id.button)
        floatingActionButton.setOnClickListener {

            Uploadimage.listner = this

            val intent =
                Intent(this, Uploadimage::class.java)
            startActivity(intent)
        }
    }

    fun GetImage() {
        recyclerView = findViewById(R.id.recyclerview)
        adapter = ImageAdapter(imageList, this)
        imageList.clear()

        recyclerView.layoutManager = LinearLayoutManager(this)
//        storageReference.listAll().addOnSuccessListener { listResult ->
//            for (fileRef in listResult.items) {
//                fileRef.downloadUrl.addOnSuccessListener { uri ->
//                    Log.d("item", "GetImage: " + uri)
//                    imageList.add(list(0, uri, fileRef))
//                    recyclerView.adapter = adapter
//                }
//            }
//        }
        storageReference.listAll().addOnSuccessListener { listResult ->
            for (fileRef in listResult.items) {
                fileRef.downloadUrl.addOnSuccessListener { uri ->
                    Log.d("item", "GetImage: " + uri)
//                    uriReference.add(uri)
                    recyclerView.adapter = adapter

                    fileRef.metadata.addOnSuccessListener {
                        Log.d("item", "GetImage: " + it.contentType)
//                        typeReference.add(it.contentType.toString())
                        imageList.add(list(0, uri, fileRef))
                        recyclerView.adapter = adapter
                    }
                }

            }

        }
    }

    override fun OnRefresh() {
        GetImage()
    }

    private fun showMessage(isConnected: Boolean) {
        if (!isConnected) {

            val messageToUser = "You are offline now."
            mSnackBar = Snackbar.make(
                findViewById(android.R.id.content),
                messageToUser,
                Snackbar.LENGTH_LONG
            ) //Assume "rootLayout" as the root layout of every activity.
            mSnackBar?.duration = Snackbar.LENGTH_INDEFINITE
            mSnackBar?.show()
        } else {
            mSnackBar?.dismiss()
        }


    }

    override fun onResume() {
        super.onResume()
        ConnectivityReceiver.connectivityReceiverListener = this
    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        showMessage(isConnected)
    }

}
