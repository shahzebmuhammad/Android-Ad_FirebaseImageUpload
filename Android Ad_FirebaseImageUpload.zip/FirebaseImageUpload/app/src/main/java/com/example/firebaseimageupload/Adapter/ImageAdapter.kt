package com.example.firebaseimageupload.Adapter


import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.firebaseimageupload.R
import com.example.firebaseimageupload.model.list
import com.google.android.ads.nativetemplates.TemplateView
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.formats.UnifiedNativeAd


class ImageAdapter() : RecyclerView.Adapter<ImageAdapter.ViewHolder>() {

    private var imageList: ArrayList<list>? = null
    private var context: Context? = null

    constructor(imageList: ArrayList<list>, context: Context?) : this() {
        this.imageList = imageList
        this.context = context

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentPosition = imageList?.get(position)

        if (position % 3 == 0 && position != 1) {

            val builder: AdLoader.Builder = AdLoader.Builder(
                context, "ca-app-pub-3940256099942544/2247696110"
            )

            builder.forUnifiedNativeAd(object : UnifiedNativeAd.OnUnifiedNativeAdLoadedListener {
                override fun onUnifiedNativeAdLoaded(unifiedNativeAd: UnifiedNativeAd?) {
                    holder.templateView.setNativeAd(unifiedNativeAd)
                    Toast.makeText(context, "Native Ad shown", Toast.LENGTH_SHORT).show()

                }
            })

            val adLoader: AdLoader = builder.build()
            Toast.makeText(context, "Native Ad Request sent", Toast.LENGTH_SHORT).show()
            adLoader.loadAd(AdRequest.Builder().build())

            holder.templateView.visibility = View.VISIBLE


        }

        Glide.with(context!!)
            .load(currentPosition?.uri.toString())
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(holder.image)

        Log.d("TAGA", "onBindViewHolder: " + currentPosition?.type)

        holder.button.setOnClickListener {
            Log.d("TAGA", "onBindViewHolder: " + currentPosition)
            url(currentPosition!!.uri.toString(), context)
        }

    }

    override fun getItemCount(): Int {
        return imageList!!.size

    }

    private fun url(urlstring: String?, context: Context?) {

        val request = DownloadManager.Request(Uri.parse(urlstring.toString()))
            .setTitle("File")
            .setDescription("Downloading")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "Download")

        val ds = context?.getSystemService(AppCompatActivity.DOWNLOAD_SERVICE) as DownloadManager
        ds.enqueue(request)
    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var templateView = itemView.findViewById<TemplateView>(R.id.my_template)

        var image = itemView.findViewById<ImageView>(R.id.imageView)
        var button = itemView.findViewById<Button>(R.id.downloadbutton)

    }
}
