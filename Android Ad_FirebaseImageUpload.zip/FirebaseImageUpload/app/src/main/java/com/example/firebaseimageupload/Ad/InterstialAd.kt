package com.example.firebaseimageupload.Ad

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.example.firebaseimageupload.AD_UNIT_ID
import com.example.firebaseimageupload.MainActivity
import com.google.android.gms.ads.*
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

const val AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

class InterstialAd (var context: Context){

    private var mInterstitialAd: InterstitialAd? = null
    private var mAdIsLoading: Boolean = false

    fun initilization(){
        MobileAds.initialize(context, object : OnInitializationCompleteListener {
            override fun onInitializationComplete(p0: InitializationStatus) {
                loadAd()
            }

        })
        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder()
                .setTestDeviceIds(listOf("ABCDEF012345"))
                .build()
        )
    }
    fun loadAd() {
        val adRequest = AdRequest.Builder().build()
        createintersitiad(adRequest)
    }
    fun createintersitiad(adRequest: AdRequest) {
        InterstitialAd.load(
            context, AD_UNIT_ID, adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {


                    val intent = Intent(context, MainActivity::class.java)
                    context.startActivity(intent)
                    mInterstitialAd = null
                    mAdIsLoading = false

                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    Log.d("TAG", "Ad was loaded.")
                    mInterstitialAd = interstitialAd
                    mAdIsLoading = true // original false
                    Toast.makeText(context, "Ad is Loading", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    fun showInterstitial() {

        if (mInterstitialAd != null) {
            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d("TAG", "Ad was dismissed.")
                    // Don't forget to set the ad reference to null so you
                    // don't show the ad a second time.
                    mInterstitialAd = null
                    val intent = Intent(context, MainActivity::class.java)
                    context.startActivity(intent)

                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d("TAG", "Ad failed to show.")
                    // Don't forget to set the ad reference to null so you
                    // don't show the ad a second time.
                    mInterstitialAd = null
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d("TAG", "Ad showed fullscreen content.")
                    // Called when ad is dismissed.
                }
            }
            mInterstitialAd?.show(context as Activity)
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.")
        }
    }
}